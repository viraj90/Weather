//
//  WeatherListViewModel.swift
//  Weather
//
//  Created by Viraj Padia on 07/04/2021.
//

import Foundation

struct WeatherListViewModel {
    
    private(set) var weatherViewModels = [WeatherViewModel]()
    
    mutating func addWeatherViewModel(_ vm: WeatherViewModel) {
        self.weatherViewModels.append(vm)
    }
    
    func numberOfRows(_ section: Int) -> Int {
        return self.weatherViewModels.count
    }
    
    func modelAt(_ index: Int) -> WeatherViewModel {
        return self.weatherViewModels[index]
    }
    
    mutating private func toCelsius() {
        
       weatherViewModels = weatherViewModels.map { vm in
            
            let weatherModel = vm
            weatherModel.temperature = (weatherModel.temperature - 32) * 5/9
            return weatherModel
            
        }
    }
    
    mutating private func toFahrenheit() {
        
        weatherViewModels = weatherViewModels.map { vm in
            
            let weatherModel = vm
            weatherModel.temperature = (weatherModel.temperature * 9/5) + 32
            return weatherModel
            
        }
        
    }
    
    mutating func updateUnit(to unit: Unit) {
        
        switch unit {
            case .celsius:
                toCelsius()
            case .fahrenheit:
                toFahrenheit()
        }
        
    }
    
}

class WeatherViewModel {
    
    let weather: Weather
    var temperature: Double
    
    init(weather: Weather) {
        self.weather = weather
        temperature = weather.currentTemperature.temperature
    }
    
    var city: String {
        return weather.name
    }
    
}
