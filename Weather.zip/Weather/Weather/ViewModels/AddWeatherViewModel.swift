//
//  AddWeatherViewModel.swift
//  Weather
//
//  Created by Viraj Padia on 07/04/2021.
//

import Foundation
import UIKit

class AddWeatherViewModel {
    
    func addWeather(for city: String, completion: @escaping (WeatherViewModel) -> Void) {
        
        let weatherURL = Constants.Urls.urlForWeatherByCity(city: city)
        
        let weatherResource = Resource<Weather>(url: weatherURL) { data in
            let weatherResponse = try? JSONDecoder().decode(Weather.self, from: data)
            return weatherResponse
        }
        
        Webservice().load(resource: weatherResource) { (result) in
            
            if let weatherResource = result {
                let vm = WeatherViewModel(weather: weatherResource)
                completion(vm)
            }
        }
        
    }
    
}


