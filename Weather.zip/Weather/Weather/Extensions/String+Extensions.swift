//
//  String+Extensions.swift
//  Weather
//
//  Created by Viraj Padia on 07/04/2021.
//

import Foundation

extension String {
    
    func escaped() -> String {
        return self.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) ?? self
    }
    
}
