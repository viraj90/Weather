//
//  Double+Extensions.swift
//  Weather
//
//  Created by Viraj Padia on 07/04/2021.
//

import Foundation

extension Double {
    
    var formatAsDegree: String {
        return String(format: "%.0f°",self)
    }
    
}
