//
//  Weather.swift
//  Weather
//
//  Created by Viraj Padia on 07/04/2021.
//

import Foundation


struct Weather: Decodable {
    
    let name: String
    var currentTemperature: Temperature
    
    private enum CodingKeys: String, CodingKey {
        case name
        case currentTemperature = "main"
    }
    
}

struct Temperature: Decodable {
    
    var temperature: Double
    let temperatureMin: Double
    let temperatureMax: Double
    
    private enum CodingKeys: String, CodingKey {
        case temperature = "temp"
        case temperatureMin = "temp_min"
        case temperatureMax = "temp_max"
    }
}
