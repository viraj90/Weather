//
//  WeatherListViewModelTests.swift
//  WeatherTests
//
//  Created by Viraj Padia on 07/04/2021.
//

import XCTest
@testable import Weather

class WeatherListViewModelTests: XCTestCase {
    private var weatherListVM: WeatherListViewModel!
    
    override func setUpWithError() throws {
        super.setUp()
        self.weatherListVM = WeatherListViewModel()
        
        self.weatherListVM.addWeatherViewModel(WeatherViewModel(weather: Weather(name: "London", currentTemperature: Temperature(temperature: 32, temperatureMin: 0, temperatureMax: 0))))
        
        self.weatherListVM.addWeatherViewModel(WeatherViewModel(weather: Weather(name: "Manchester", currentTemperature: Temperature(temperature: 75, temperatureMin: 0, temperatureMax: 0))))
        
    }
    
    func test_should_be_able_to_convert_to_celsius_successfully() {
        
        let celsiusTemperatures = [0,24.2222]
        self.weatherListVM.updateUnit(to: .celsius)
        
        for (index, vm) in self.weatherListVM.weatherViewModels.enumerated() {
            XCTAssertEqual(round(vm.temperature), round(celsiusTemperatures[index]))
        }
    }
    
    func test_should_be_able_check_modelat_index() {
        
        for (index, vm) in self.weatherListVM.weatherViewModels.enumerated() {
            let WeatherModel = self.weatherListVM.modelAt(index)
            XCTAssertEqual(WeatherModel.city, vm.city)
            XCTAssertEqual(WeatherModel.temperature, vm.temperature)
        }
    }
    
    func test_should_be_able_to_convert_to_fahrenheit_successfully() {
        
        let fahrenheitTemperatures = [90.0,167.0]
        self.weatherListVM.updateUnit(to: .fahrenheit)
        
        for (index, vm) in self.weatherListVM.weatherViewModels.enumerated() {
            XCTAssertEqual(round(vm.temperature), round(fahrenheitTemperatures[index]))
        }
        
    }
    
    func test_should_be_able_to_return_cityname_successfully() {
        
        let cityNames = ["London","Manchester"]
        for (index, vm) in self.weatherListVM.weatherViewModels.enumerated() {
            XCTAssertEqual(vm.city, cityNames[index])
        }
    }
    
    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
}
