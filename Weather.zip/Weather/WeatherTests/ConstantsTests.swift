//
//  ConstantsTests.swift
//  WeatherTests
//
//  Created by Viraj Padia on 07/04/2021.
//

import XCTest
@testable import Weather

class ConstantsTests: XCTestCase {
    
    private var city: String!
    private var WeatherURL: URL!

    override func setUpWithError() throws {
        self.city = "London"
        
        let userDefaults = UserDefaults.standard
        let unit = (userDefaults.value(forKey: "unit") as? String)
        
        if let unit = unit {
            WeatherURL = URL(string: "https://api.openweathermap.org/data/2.5/weather?q=\(city.escaped())&appid=ef0fd9866ca027e0dca474cee84c53be&units=\(unit)")
        }
        
        
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    func test_should_return_correct_url_format() {
        XCTAssertEqual(WeatherURL, Constants.Urls.urlForWeatherByCity(city: self.city))
    }


}
