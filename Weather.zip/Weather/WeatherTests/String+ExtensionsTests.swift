//
//  String_ExtensionsTests.swift
//  WeatherTests
//
//  Created by Viraj Padia on 07/04/2021.
//

import XCTest
@testable import Weather

class String_ExtensionsTests: XCTestCase {
    private var city : String!

    override func setUpWithError() throws {
        city = "Los Angeles"
    }

    func test_should_return_correct_string_format_which_accepts_URLhosts() {
        XCTAssertEqual(self.city.escaped(), "Los%20Angeles")
    }

}
