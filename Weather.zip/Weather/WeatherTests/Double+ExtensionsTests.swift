//
//  Double+ExtensionsTests.swift
//  WeatherTests
//
//  Created by Viraj Padia on 07/04/2021.
//

import XCTest
@testable import Weather

class Double_ExtensionsTests: XCTestCase {

    private var degree : Double!
    
    override func setUpWithError() throws {
        degree = 20
    }
    
    func test_should_return_correct_string_format_for_temperature() {
        XCTAssertEqual("20°", self.degree.formatAsDegree)
    }

    

}
