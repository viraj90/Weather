//
//  WeatherListViewControllerTests.swift
//  WeatherTests
//
//  Created by Viraj Padia on 07/04/2021.
//

import XCTest
@testable import Weather

class WeatherListViewControllerTests: XCTestCase {
    
    var viewControllerUnderTest: WeatherListTableViewController!
    
    override func setUpWithError() throws {
        super.setUp()
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        self.viewControllerUnderTest = storyboard.instantiateViewController(withIdentifier: "WeatherListTableViewController") as? WeatherListTableViewController
        
        self.viewControllerUnderTest.loadView()
        self.viewControllerUnderTest.viewDidLoad()
        
    }
    
    func test_has_tableView() {
        XCTAssertNotNil(viewControllerUnderTest.tableView)
    }
    
    func test_tableView_has_Delegate() {
        XCTAssertNotNil(viewControllerUnderTest.tableView.delegate)
    }
    
    func test_TableView_Confroms_To_TableViewDelegateProtocol() {
        XCTAssertTrue(viewControllerUnderTest.conforms(to: UITableViewDelegate.self))
        XCTAssertFalse(viewControllerUnderTest.responds(to: #selector(viewControllerUnderTest.tableView(_:didSelectRowAt:))))
    }
    
    func test_TableView_Conforms_To_TableViewDataSourceProtocol() {
        XCTAssertTrue(viewControllerUnderTest.conforms(to: UITableViewDataSource.self))
        XCTAssertTrue(viewControllerUnderTest.responds(to: #selector(viewControllerUnderTest.tableView(_:numberOfRowsInSection:))))
        XCTAssertTrue(viewControllerUnderTest.responds(to: #selector(viewControllerUnderTest.tableView(_:cellForRowAt:))))
    }
    
    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    
    
}
